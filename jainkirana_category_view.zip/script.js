fetch('products.json')
  .then(res => res.json())
  .then(data => {
    const categoryList = document.getElementById('category-list');
    const productList = document.getElementById('product-list');

    Object.keys(data).forEach(category => {
      const btn = document.createElement('button');
      btn.textContent = category;
      btn.onclick = () => showProducts(category, data[category]);
      btn.style.margin = '5px';
      categoryList.appendChild(btn);
    });

    function showProducts(category, products) {
      productList.innerHTML = `<h2>${category}</h2>`;
      products.forEach(product => {
        productList.innerHTML += `
          <div class="product">
            <h3>${product.name}</h3>
            <p>Price: ₹${product.price}</p>
            <p>Weight: ${product.weight}</p>
            <button onclick="addToCart('${product.name}', ${product.price}, '${product.weight}')">Add to Cart</button>
          </div>
        `;
      });
    }
  });

function addToCart(name, price, weight) {
  let cart = JSON.parse(localStorage.getItem('cart')) || [];
  cart.push({ name, price, weight });
  localStorage.setItem('cart', JSON.stringify(cart));
  alert(`${name} added to cart!`);
}
